bl_info = {
    "name": "BloomOcclusion",
    "author": "Checktech",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > ToolShelf > Bloom Occlusion",
    "description": "Adds a Bloom And Ambient Occlusion With one Click!",
    "warning": "Still in Bata Phases",
    "doc_url": "",
    "category": "Add Setting",
}
























import bpy





class MyProperties(bpy.types.PropertyGroup):
    
  
    """Click to add or delete Bloom And Ambient Occlusion"""
    my_enum : bpy.props.EnumProperty(
        name= "Choose Option",
        description= "What it Does!",
        items= [('OP1', "Add Bloom", ""),
                ('OP2', "Delete  Bloom", ""),
                ('OP3', "Add Ambient Occlusion", ""),
                ('OP4', "Delete Ambient Occlusion", "")
        ]
    )





class ADDONNAME_PT_main_panel(bpy.types.Panel):
    bl_label = "Bloom Occlusion"
    bl_idname = "ADDONNAME_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BloomOcclusion"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
       
        layout.prop(mytool, "my_enum")

        layout.operator("addonname.myop_operator")






class ADDONNAME_OT_my_op(bpy.types.Operator):
    bl_label = "Add Setting"
    bl_idname = "addonname.myop_operator"
    
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        
        if mytool.my_enum == 'OP1':
           bpy.context.scene.eevee.use_bloom = True
        


            
            
        if mytool.my_enum == 'OP2':
            bpy.context.scene.eevee.use_bloom = False
        
        
        
        
        if mytool.my_enum == 'OP3':
            bpy.context.scene.eevee.use_gtao = True
        
            
        
        if mytool.my_enum == 'OP4':
           bpy.context.scene.eevee.use_gtao = False
     
        return {'FINISHED'}
    









classes = [MyProperties, ADDONNAME_PT_main_panel, ADDONNAME_OT_my_op]
 
 
 
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
        bpy.types.Scene.my_tool = bpy.props.PointerProperty(type= MyProperties)
 
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
        del bpy.types.Scene.my_tool
 
 
 
if __name__ == "__main__":
    register()